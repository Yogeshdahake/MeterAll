package com.arc.yogesh.meterall;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.net.ConnectException;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LocationListener {

    TextView tv,tv2,tv3,tv4;
   private View view;
    private double latitude,longitude;

    private LocationManager locationManager;
    private WifiManager wifiManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main
        tv4=(TextView)findViewById(R.id.tv4);
        tv = (TextView) findViewById(R.id.tv);
        tv2=(TextView)findViewById(R.id.tv2);
        tv3=(TextView)findViewById(R.id.tv3);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        wifiManager=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location location = locationManager.getLastKnownLocation(locationManager.NETWORK_PROVIDER);

        onLocationChanged(location);
        loc_fun(location);
        getWifiInfo(view);




    }

    @Override
    public void onLocationChanged(Location location) {

        longitude=location.getLongitude();
       latitude=location.getLatitude();
        double altitude=location.getAltitude();




        tv.setText("Longitude:   "+longitude+"\n"+"Latitude:   "+latitude+"\n"+"Altitude:   "+altitude);

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
        private void loc_fun(Location location)
         {
        Geocoder geocoder = new Geocoder(this);
        List<Address> addresses=null;
        try
             {
            addresses=geocoder.getFromLocation(latitude,longitude,1);
            String country=addresses.get(0).getCountryName();
            String state=addresses.get(0).getAdminArea();
            String city= addresses.get(0).getLocality();

            String poscode=addresses.get(0).getPostalCode();

            tv2.setText("Country:   "+country+"\n"+"State:   "+state+"\n"+"City:   "+city+"\n"+"Postel Code:   "+poscode);
            }
        catch (IOException e)
            {
            e.printStackTrace();
            Toast.makeText(this, "Error!!", Toast.LENGTH_SHORT).show();
            }


    }

    public void getWifiInfo(View view)
    {
        try {

            if (wifiManager.isWifiEnabled()) {
                WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                try {
                    if (String.valueOf(wifiInfo.getSupplicantState()).equals("COMPLETED")) {
                        try {
                            Toast.makeText(this, "You Are Connected to " + wifiInfo.getSSID(), Toast.LENGTH_SHORT).show();
                            tv3.setText("SSID:   " + wifiInfo.getSSID() + "\n" + "IP Address:   " + wifiInfo.getIpAddress() + "\n" + "Signal Strength:    " + wifiInfo.getRssi() + "\n" + "Frequency:   " + wifiInfo.getFrequency() + "\n" + "Mac Address:   " + wifiInfo.getBSSID() + "\n" + "Link Speed:   " + wifiInfo.getLinkSpeed());
                        } catch (Exception e) {
                            e.getMessage();
                        }

                    }
                } catch (Exception e) {
                    e.getMessage();
                }

            } else {
                tv3.setText("Please Turn On WiFi!");
            }
        }catch(Exception e)
        {
            e.getMessage();
        }
    }

}
